use App\Http\Controllers\DashboardController;
Route::get('dashboardcount', [DashboardController::class, 'index']);