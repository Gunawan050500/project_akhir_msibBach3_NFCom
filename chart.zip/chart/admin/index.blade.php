
{{--  Tambahan js untuk membuat dashboard  --}}
  <script src="{{ asset('admin/vendor/chart.js/chart.min.js')}}"></script> 
